<?php
// phpcs:disable
// Silence is golden.
